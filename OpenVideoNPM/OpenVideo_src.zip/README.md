To build the extension run "npm i" and "npm run export"
