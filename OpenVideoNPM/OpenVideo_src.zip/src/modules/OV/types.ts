export type StdMap<T> = { [key: string]: T };
export type StringMap = StdMap<string>;
