declare module "*.svg";
